<?php 
namespace App\Models;

class UserModel 
{
    private $name;
    private $username;
    private $password;
    
    // Class Constructor
    public function __construct($name, $username, $password)
    {
        $this->name = $name;
        $this->username = $username;
        $this->password = $password;
    }   
    
    /**
     * Getter Method -> username
     */
    public function getName()
    {
        return $this->name;
    }
    /**
     * Getter Method -> username
     */
    public function getUsername()
    {
        return $this->username;
    }
    /**
     * Getter Method -> password
     * @return string
     */
    public function getPassword()
    {
        return $this->password;
    }
}