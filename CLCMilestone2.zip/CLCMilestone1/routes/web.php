<?php

// Alexander Carrillo & Jeanna Benitez

// CST - 256

// Feb. 7th, 2021

// This assignment was completed in collaboration with Alexander Carrillo and Jeanna Benitez

// We used source code from the following websites to complete this assignment:
// https://www.youtube.com/watch?v=Mh7DTsveHsk&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=42
// https://www.youtube.com/watch?v=Ds7rntR5E64&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=43
// https://www.youtube.com/watch?v=yyHeqTZEINU&list=PL78sHffDjI74qqNlqtqV_tx5E0_NG1IXQ&index=44

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');
Route::get('/profile', function() {return view('profile');});



Route::get('users', 'UsersController@index')->name('users.index');

Route::get('users/profile', 'UsersController@edit')->name('users.edit-profile');  

Route::put('users/profile', 'UsersController@update')->name('users.update-profile');

  
  
  
  
  // This will make sure the user is authenticated and is an admin
Route::middleware(['auth', 'admin'])->group(function (){
    
  
    Route::get('users', 'UsersController@index')->name('users.index');
    
    Route::post('users/{user}/make-admin', 'UsersController@makeAdmin')->name('users.make-admin');
    
});
